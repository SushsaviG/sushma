﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            TdsData td = new TdsData();
            td.SetTID("14");
            td.SetTValue("8");
            string tradid = td.GetTID();
            string tradevalue = td.GetTValue();
            RdsData rd = new RdsData();
            rd.SetCPI("15");
            rd.SetCPN("sushma");
            string CPI = rd.GetCPI();
            string CPN = rd.GetCPN();
            System.Console.WriteLine();
            Console.ReadLine();

        }
    }
}
