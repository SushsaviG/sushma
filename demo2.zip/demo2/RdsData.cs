﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo2
{
    class RdsData
    {
        private string counterpartyid;
        private string counterpartyname;
        public string GetCPI()
        {
            return this.counterpartyid;
        }
        public string GetCPN()
        {
            return this.counterpartyname;
        }
        public void SetCPI(string value)
        {
            this.counterpartyid = value;
        }
        public void SetCPN(string value)
        {
            this.counterpartyname = value;
        }
    }
}
