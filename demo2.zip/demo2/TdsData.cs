﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo2
{
    class TdsData
    {
        private string tradeid;
        private string tradevalue;
        private string counterpartyid;
        public string GetTID()
        {
            return this.tradeid;
        }
        public string GetTValue()
        {
            return this.tradevalue;
        }
        public string GetCPID()
        {
            return this.counterpartyid;
        }
        public void SetTID(string value)
        {
            this.tradeid = value;
        }
        public void SetTValue(string value) { this.tradevalue = value; }

    }
}
